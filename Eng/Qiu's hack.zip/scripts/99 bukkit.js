﻿HackFunctions.setItemArrayOffset(HackFunctions.OFFSET_ARMOR);
HackFunctions.SetItemDefaults(10,205,0);
HackFunctions.setItemStack(10,99);
HackFunctions.setItemArrayOffset(HackFunctions.OFFSET_INV);